#include "DoublyLinkedList.hpp"

DoublyLinkedList::Node::Node(DataType data)
{
}

DoublyLinkedList::DoublyLinkedList()
{
}

DoublyLinkedList::~DoublyLinkedList()
{
}

bool DoublyLinkedList::empty() const
{
}

unsigned int DoublyLinkedList::size() const
{
}

void DoublyLinkedList::print() const
{
}

bool DoublyLinkedList::insert_front(DataType value)
{
}

bool DoublyLinkedList::remove_front()
{
}

bool DoublyLinkedList::insert_back(DataType value)
{
}

bool DoublyLinkedList::remove_back()
{
}

bool DoublyLinkedList::insert(DataType value, unsigned int index)
{
}

bool DoublyLinkedList::remove(unsigned int index)
{
}

unsigned int DoublyLinkedList::search(DataType value) const
{
}

DoublyLinkedList::DataType DoublyLinkedList::select(unsigned int index) const
{
}

bool DoublyLinkedList::replace(unsigned int index, DataType value)
{
}

DoublyLinkedList::Node* DoublyLinkedList::getNode(unsigned int index) const
{
}
bool DoublyLinkedList::full() const
{
}
